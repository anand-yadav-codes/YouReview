package org.YouReview.dto;

public class Reviews {
	private String Product_Name;
	private String User_UserName;
	private int Answer1;
	private int Answer2;
	private int Answer3;
	private int Answer4;
	private int Answer5;
	private String Comment;
	public String getProduct_Name() {
		return Product_Name;
	}
	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}
	public String getUser_UserName() {
		return User_UserName;
	}
	public void setUser_UserName(String user_UserName) {
		User_UserName = user_UserName;
	}
	public int getAnswer1() {
		return Answer1;
	}
	public void setAnswer1(int answer1) {
		Answer1 = answer1;
	}
	public int getAnswer2() {
		return Answer2;
	}
	public void setAnswer2(int answer2) {
		Answer2 = answer2;
	}
	public int getAnswer3() {
		return Answer3;
	}
	public void setAnswer3(int answer3) {
		Answer3 = answer3;
	}
	public int getAnswer4() {
		return Answer4;
	}
	public void setAnswer4(int answer4) {
		Answer4 = answer4;
	}
	public int getAnswer5() {
		return Answer5;
	}
	public void setAnswer5(int answer5) {
		Answer5 = answer5;
	}
	public String getComment() {
		return Comment;
	}
	public void setComment(String comment) {
		Comment = comment;
	}
	
}
